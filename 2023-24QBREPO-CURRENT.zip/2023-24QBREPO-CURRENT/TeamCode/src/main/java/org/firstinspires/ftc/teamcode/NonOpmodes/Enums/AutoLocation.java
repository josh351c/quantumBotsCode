package org.firstinspires.ftc.teamcode.NonOpmodes.Enums;

public enum AutoLocation {
    BLUE_SHORT,
    BLUE_LONG,
    RED_SHORT,
    RED_LONG
}
