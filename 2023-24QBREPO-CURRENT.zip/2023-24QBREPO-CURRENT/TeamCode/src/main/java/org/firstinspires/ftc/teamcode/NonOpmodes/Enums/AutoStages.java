package org.firstinspires.ftc.teamcode.NonOpmodes.Enums;

public enum AutoStages {
    SPIKE_MARK,
    PIXEL_DEPOSIT,
    INITIAL_EXTEND,
    CYCLE_EXTEND,
    INTAKE,
    RETRACT,
    TRANSFER,
    DEPOSIT,
    PARK
}
