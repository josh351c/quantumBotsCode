package org.firstinspires.ftc.teamcode.NonOpmodes.Enums;

public enum SpikeMark {
    LEFT,
    MIDDLE,
    RIGHT
}
