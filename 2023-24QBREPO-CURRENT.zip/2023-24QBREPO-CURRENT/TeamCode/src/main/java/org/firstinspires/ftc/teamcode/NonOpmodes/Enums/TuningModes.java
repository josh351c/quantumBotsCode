package org.firstinspires.ftc.teamcode.NonOpmodes.Enums;

public enum TuningModes {
    FINE_TUNE,
    OPERATIONAL
}