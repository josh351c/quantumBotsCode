package org.firstinspires.ftc.teamcode.NonOpmodes.Roadrunner.trajectorysequence;


public class EmptySequenceException extends RuntimeException { }
