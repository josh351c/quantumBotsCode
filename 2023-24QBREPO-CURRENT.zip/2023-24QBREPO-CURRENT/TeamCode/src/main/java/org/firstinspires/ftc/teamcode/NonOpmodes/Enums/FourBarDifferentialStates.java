package org.firstinspires.ftc.teamcode.NonOpmodes.Enums;

public enum FourBarDifferentialStates {
    INIT,
    INTERMEDIATE_PTD,
    INTERMEDIATE_DTP,
    PICKUP,
    DEPOSIT
}
